import ShotsDashboard from "./ShotsDashboard";


const Task2 = () => {


  return (
    <div className="app-container">
      <ShotsDashboard />
    </div>
  );
}


export default Task2;
