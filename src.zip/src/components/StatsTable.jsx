import { Table } from "antd";
import { useContext, useEffect, useState } from "react";
import Papa from 'papaparse';
import { sortFunc } from '../utils/sorterFunction';
import { MatchStatsContext } from "../context/MatchStatsContext";
import ScrollableContainer from "./containers/ScrollableContainer";

const csvFile = require("../data/stats.csv")


const StatsTable = (props) => {

    const { matchStats, dispatchMatchStats, dispatchChartFilter } = useContext(MatchStatsContext)
    const [displayCategory, setDisplayCategory] = useState(null)
    // const [display, setDisplay] = useState(null)

    // useEffect(() => {
    //     if (!displayCategory && matchStats) {
    //         setDisplayCategory(false)
    //     }
    // })

    // useEffect(() => {

    //     Papa.parse(csvFile, {
    //         download: true,
    //         complete: (result) => {
    //             const columnsArr = []
    //             const dataSourceArr = []

    //             const columnTitles = result.data[5]

    //             columnTitles.forEach(column => {
    //                 columnsArr.push({
    //                     title: column,
    //                     dataIndex: column,
    //                     key: column,
    //                     sorter: (a, b) => sortFunc(a, b, column),
    //                     sortDirections: ['descend', 'ascend'],
    //                 })
    //             });

    //             for (let i = 0; i < result.data.length - 6; i++) {

    //                 const row = result.data[i + 6]
    //                 const athleteData = { key: i }

    //                 row.forEach((element, i) => {
    //                     athleteData[columnTitles[i]] = element
    //                 });
    //                 dataSourceArr.push(athleteData)
    //             }

    //             dispatchMatchStats({
    //                 columns: columnsArr,
    //                 dataSource: dataSourceArr
    //             })
    //         }
    //     })
    // }, [dispatchMatchStats])


    const handleToggleCategory = () => {
        setDisplayCategory((prev) => { return !prev })
    }

    const categorizedColumns = displayCategory ?

        matchStats?.columns.slice(0, 1).concat(matchStats.columns.slice(16))
        :
        matchStats?.columns.slice(0, 16)


    return (
        <>
            <button
                onClick={() => { handleToggleCategory() }}
            >Toggle Touches / Passes display category  </button>

            {
                !!matchStats &&
                <ScrollableContainer>
                    <Table
                        onChange={() => dispatchChartFilter(localStorage.getItem("chartFilter"))}
                        dataSource={matchStats.dataSource} columns={categorizedColumns}
                    />
                </ScrollableContainer>
            }
        </>
    );
}


export default StatsTable;
