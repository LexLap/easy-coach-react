import { useEffect } from "react";
import { useContext } from "react";
import Chart from "react-apexcharts";
import { MatchStatsContext } from "../context/MatchStatsContext";

const BarChart = (props) => {


    const { matchStats, chartFilter } = useContext(MatchStatsContext)
    // const chartFilter = props.chartFilter
    // localStorage.getItem("chartFilter")

    // useEffect(() => {
    //     console.log(chartFilter)

    // }, [chartFilter])

    const options = matchStats ? {
        chart: {
            id: "basic-bar"
        },
        xaxis: {
            categories: matchStats.dataSource.map((elm) => elm.Athlete.split(' ')[2])
        }
    } : {}

    const series = matchStats ? [
        {
            name: chartFilter,
            data: chartFilter != "Started" ?
                matchStats.dataSource.map((elm) => elm[chartFilter])
                :
                matchStats.dataSource.map((elm) => {
                    if (elm[chartFilter] === "X") return 1
                    else return 0
                })
        }
    ] : []


    return (
        <>
            <div style={{ height: "30%" }}>
                <Chart
                    options={options}
                    series={series}
                    type="bar"
                    width="100%"
                    height="100%"
                />
            </div>
        </>
    );
}

export default BarChart;
