import { useState } from "react";
import BarChart from "./BarChart";
import StatsTable from "./StatsTable";


const App = () => {

  const [chartFilter, dispatchChartFilter] = useState("Started")

  const setChartFilter = () => {
    dispatchChartFilter(localStorage.getItem("chartFilter"))
  }

  return (
    <div className="app-container">
      <StatsTable setChartFilter={setChartFilter} />
      <BarChart chartFilter={chartFilter} />
    </div>
  );
}

export default App;
