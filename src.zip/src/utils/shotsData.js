const jsonData = require('../data/shots.json')

export const getShotsData = () => {
    return jsonData
}