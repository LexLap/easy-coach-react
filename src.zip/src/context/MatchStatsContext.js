import { createContext, useEffect, useState } from 'react';
import Papa from 'papaparse';
import { sortFunc } from '../utils/sorterFunction';

const csvFile = require("../data/stats.csv")


export const MatchStatsContext = createContext();


const MatchStatsContextProvider = (props) => {

    const [matchStats, dispatchMatchStats] = useState(null);
    const [chartFilter, dispatchChartFilter] = useState("Started")

    Papa.parsePromise = (file) => {
        return new Promise(function (complete, error) {
            Papa.parse(file, { download: true, complete, error });
        });
    };

    const columnsArr = []
    const dataSourceArr = []

    Papa.parsePromise(csvFile).then((result) => {
        const columnTitles = result.data[5]

        columnTitles.forEach(column => {
            columnsArr.push({
                title: column,
                dataIndex: column,
                key: column,
                sorter: (a, b) => { return sortFunc(a, b, column) },
                sortDirections: ['descend', 'ascend'],
            })
        });

        for (let i = 0; i < result.data.length - 6; i++) {

            const row = result.data[i + 6]
            const athleteData = { key: i }

            row.forEach((element, i) => {
                athleteData[columnTitles[i]] = element
            });
            dataSourceArr.push(athleteData)
        }

        if (!matchStats)
            dispatchMatchStats({
                columns: columnsArr,
                dataSource: dataSourceArr
            })

    });


    return (
        <MatchStatsContext.Provider value={{
            matchStats, dispatchMatchStats,
            chartFilter, dispatchChartFilter
        }}>
            {props.children}
        </MatchStatsContext.Provider>
    );
};

export default MatchStatsContextProvider;
